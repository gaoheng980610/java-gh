# Command Line Calculator

This Java program is a simple command line calculator that supports basic arithmetic operations (+, -, *, /). Users can enter two numbers and an operator to perform calculations. Use this calculator for quick mathematical computations in the terminal.
